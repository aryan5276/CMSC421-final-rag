import gradio as gr  
import os  
from google.cloud import storage  
from flask_app.extract_data import download_and_store
from flask_app.chunking.create_chunks import create_chunks
from flask_app.chunking.vectorize import vectorize
from flask_app.querying.pinecone_query import call_openai, get_matches


def get_latest_folder_number(bucket_name="rag_documents_bitcamp"):  
    storage_client = storage.Client()  
    bucket = storage_client.bucket(bucket_name)  
      
    blobs = bucket.list_blobs()  
    folder_numbers = set()  
  
    for blob in blobs:  
        # print(blob.name)
        if blob.name.endswith('/'): 
            folder_name = blob.name.rstrip('/')  
            if folder_name.startswith("test_"):  
                folder_numbers.add(int(folder_name.split("_")[1]))  
        elif "/" in blob.name:
            folder_name = blob.name.split("/")[0]
            if folder_name.startswith("test_"):  
                folder_numbers.add(int(folder_name.split("_")[1]))  
      
    if folder_numbers:  
        return max(folder_numbers) + 1  
    else:  
        return 1
  
def create_next_folder(bucket_name):  
    latest_folder_number = get_latest_folder_number(bucket_name)  
    next_folder_name = f"test_{latest_folder_number}"  
      
    storage_client = storage.Client()  
    bucket = storage_client.bucket(bucket_name)  
    blob = bucket.blob(f"{next_folder_name}/")
    blob.upload_from_string('')  
      
    return next_folder_name  
  
def upload_files(files):    
    """Uploads files to a Google Cloud Storage bucket."""    
    
    bucket_name = "rag_documents_bitcamp"    
    
    storage_client = storage.Client()    
    
    bucket = storage_client.get_bucket(bucket_name)    
    
    next_folder_name = create_next_folder(bucket_name)    
  
    for filename in files: 
        print("uploading", filename)
        blob = bucket.blob(f"{str(next_folder_name)}/{str(filename)}")    
        blob.upload_from_filename(filename)    


    return process_files(next_folder_name) 
  
def process_files(dir):
    # extracting text from files and adding to bigquery table "extracted_text"
    if download_and_store(dir):
        # chunking text
        if create_chunks(dir):
            # creating vectors and upserting
            if vectorize(dir):
                return "All Files Processed"
            else:
                return ("Error in vectorization")
        else:
            return ("Error in Chunking text")
    else:
        return ("Error in Extracting text")

def query_rag(query, dir=None):  
    if dir is None:  
        dir = get_latest_folder_number("rag_documents_bitcamp") - 1  # Assuming you want the latest complete folder  
    return call_openai(get_matches(query, f"test_{dir}"), model="gpt-3.5-turbo") 

with gr.Blocks() as app:  
    with gr.Row():  
        file_input = gr.Files(label="Select files to upload")  
        submit_button = gr.Button("Upload")  
    output_text = gr.Textbox()  
      
    submit_button.click(upload_files, inputs=file_input, outputs=output_text) 

    with gr.Row():  
        query_input = gr.Textbox(label="Enter your query")  
        query_button = gr.Button("Submit Query")  
    query_output = gr.Textbox(label="Query Response")  
        
    def submit_query(query):  
        # Assuming the directory to query is always the latest complete one  
        dir = get_latest_folder_number("rag_documents_bitcamp") - 1  
        response = query_rag(query, dir)  
        return response  
        
    query_button.click(submit_query, inputs=query_input, outputs=query_output)  
     
  
app.launch()  
