from google.cloud import bigquery  
import pandas as pd


client = bigquery.Client(project="compact-marker-420904")  

table_id = "compact-marker-420904.rag_data.chunks"  

query = f"""  
    SELECT *  
    FROM `{table_id}`
    where filename like "test_1%"  
"""  
df = client.query(query).to_dataframe()

vectors =  []

# print(df)


for index, row in df.iterrows():  
    # Process each row  
    print(row['filename'])
    print(row)

    mapping = {}
    mapping["id"] = row['id']
    mapping["values"] = get_embedding(row['text'])
    
    vectors.append(mapping)

    # # add vector to the bigquery row using row['id']
    # update_query = f"""  
    #     UPDATE `{table_id}`  
    #     SET vectors = {mapping["values"]}  
    #     WHERE id = '{mapping["id"]}'  
    # """  
    # update_job = client.query(update_query)  
    # update_job.result()  # Wait for the job to complete.  

    # print(f'Updated vectors for id: {mapping["id"]}') 

    # break

print(vectors)