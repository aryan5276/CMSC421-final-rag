
from google.cloud import storage  
 
  
  
# Your existing functions: get_latest_folder_number, create_next_folder, upload_files, process_files, query_rag  
def get_latest_folder_number(bucket_name="rag_documents_bitcamp"):  
    storage_client = storage.Client()  
    bucket = storage_client.bucket(bucket_name)  
      
    blobs = bucket.list_blobs()  
    folder_numbers = set()  
  
    for blob in blobs:  
        print(blob.name)
        if blob.name.endswith('/'):  
            folder_name = blob.name.rstrip('/')  
            if folder_name.startswith("test_"):  
                folder_numbers.add(int(folder_name.split("_")[1]))  
        elif "/" in blob.name:
            folder_name = blob.name.split("/")[0]
            if folder_name.startswith("test_"):  
                folder_numbers.add(int(folder_name.split("_")[1]))  
      
    if folder_numbers:  
        return max(folder_numbers) + 1  
    else:  
        return 1

print(get_latest_folder_number())