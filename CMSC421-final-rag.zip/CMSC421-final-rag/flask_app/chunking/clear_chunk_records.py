from google.cloud import bigquery  
  
client = bigquery.Client(project="compact-marker-420904")  
  
table_id = "compact-marker-420904.rag_data.vectors"  
  
query = f"DELETE FROM `{table_id}` WHERE true"  
  
query_job = client.query(query)  
  
errors = query_job.result()  
  
print(errors)
print("All rows deleted from the table {}".format(table_id))  
