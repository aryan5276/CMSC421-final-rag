from pinecone import Pinecone, ServerlessSpec

pc = Pinecone(api_key='dcad7eaf-c27a-4a20-b0ad-ba757d28f9a1')
index = pc.Index("bitcamp")

print(index.describe_index_stats())

if "test_1" in index.describe_index_stats()['namespaces']:
    print(True)