# read text bigquery, divide it into chunks, add it to bigquery table called chunks along with all other fields from the original bigquery table extracted_text
from google.cloud import bigquery  
import re
  
def create_chunks(dir):
    print("Creating Chunks...")
    client = bigquery.Client()  
    
    dataset_id = 'rag_data'  
    table_id = 'extracted_text'  
    
    # table_ref = client.dataset(dataset_id).table(table_id)  
    table_id = "compact-marker-420904.rag_data.extracted_text" 
    table = client.get_table(table_id)  
    
    def clean_text(text):  
        cleaned_text = re.sub(r"[^\w\s.,']", ' ', text)  
        cleaned_text = re.sub(r'\s+', ' ', cleaned_text) 
        return cleaned_text 

    def chunk_text(text, length=4500):
        cleaned_text = clean_text(text)  
        return [cleaned_text[i:i+length] for i in range(0, len(cleaned_text), length)]  

    new_schema = table.schema[:]  
    new_schema.append(bigquery.SchemaField('chunk', 'STRING'))
    
    rows = client.list_rows(table)  
    
    new_rows = []  
    for row in rows:  
        if not row.id[:len(dir)] == dir:
            continue
        chunks = chunk_text(row.text)  
        for i, chunk in enumerate(chunks):  
            new_row = dict(row)  
            new_row['id'] = f"{row['id']}_chunk_{i}"  
            new_row['text'] = chunk  
            new_row['character_length'] = len(chunk)  
            new_rows.append(new_row)  
    
    # client.delete_table(table_ref)  
    
    table_id = "compact-marker-420904.rag_data.chunks" 
    # table_ref = client.dataset(dataset_id).table(table_id)
    # new_table = bigquery.Table(table_ref, schema=table.schema)  
    new_table = client.get_table(table_id)  


    
    errors = client.insert_rows(new_table, new_rows)  

    if errors:  
        print('Errors:', errors)  
        return False
    else:  
        print('Chunked rows successfully')
        return True


create_chunks("test_21")