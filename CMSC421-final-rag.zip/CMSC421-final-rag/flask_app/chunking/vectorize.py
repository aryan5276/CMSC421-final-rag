# create index for new set of documents which would be named after the directory name which occurs first in the filename column in the bigquery table
# read chunks from table "chunks" in dataset "rag_data"
# create vectors for each chunk and append vector to the bigquery table in column vector as well as upsert to pinecone index
from pinecone import Pinecone, ServerlessSpec
from google.cloud import bigquery  
from openai import OpenAI
import itertools


def get_embedding(text, model="text-embedding-3-large"):
    openai_api_key = ""
    client = OpenAI(api_key=openai_api_key)
    text = text.replace("\n", " ")
    return client.embeddings.create(input = [text], model=model).data[0].embedding
  

def vectorize(dir):
    print("Started Creating Vectors and Uploading to Bigquery")
    client = bigquery.Client(project="compact-marker-420904")  

    table_id = "compact-marker-420904.rag_data.chunks"  
    
    query = f"""  
        SELECT *  
        FROM `{table_id}`
        where filename like "{dir}%"  
    """  
    df = client.query_and_wait(query).to_dataframe()
    
    vectors =  []
    rows = []

    vector_table = client.get_table(client.dataset("rag_data").table("vectors"))
    
    c = 0
    for index, row in df.iterrows():  
        mapping = {}
        mapping["id"] = row['id']
        mapping["values"] = get_embedding(row['text'])
        
        vectors.append(mapping)

        row['vectors'] = str(mapping)
        rows.append(row)

        c += 1
        if c % 100 == 0:
            errors = client.insert_rows(vector_table, rows)  
            if errors != []:
                print(errors)
            rows = []
            print(f'Processed {c} rows')

    if rows:
        errors = client.insert_rows(vector_table, rows)  
        if errors != []:
            print(errors)
        print(f'Processed {len(rows)} rows')
        

            
    print("Vectors Created, Added to SQL Table")
    return upsert(vectors, dir)


def chunks(iterable, batch_size=100):
    """A helper function to break an iterable into chunks of size batch_size."""
    it = iter(iterable)
    chunk = tuple(itertools.islice(it, batch_size))
    while chunk:
        yield chunk
        chunk = tuple(itertools.islice(it, batch_size))


def upsert(vectors, namespace):
    print("Starting Upserts to Vector Database")
    pc = Pinecone(api_key='dcad7eaf-c27a-4a20-b0ad-ba757d28f9a1')
    index = pc.Index("bitcamp")

    # delete vectors from namespace if it already exists
    if namespace in index.describe_index_stats()['namespaces']:
        index.delete(delete_all=True, namespace=namespace)

    vector_dim = 3072
    vector_count = len(vectors)

    c = 0
    # Upsert data with 100 vectors per upsert request
    for ids_vectors_chunk in chunks(vectors, batch_size=100):
        index.upsert(vectors=ids_vectors_chunk, namespace=namespace) 
        c += 1
        print(f"batch {c} upserted")
    print("All Vectors Upserted Successfully")
    return True



# vectorize("test_1")
