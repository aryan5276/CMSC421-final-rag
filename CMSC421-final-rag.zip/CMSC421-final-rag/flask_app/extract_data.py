from google.cloud import storage  
from pdfminer.high_level import extract_text  
from io import BytesIO  
from google.cloud import bigquery  
import datetime  
  
# print("started")  
storage_client = storage.Client()  
  
bucket = storage_client.bucket("rag_documents_bitcamp")  
  
# print("hi")  
client = bigquery.Client()  
# print("hi")  


  
def download_and_store(blob_name):
    print("extracting data from files")  
    blobs = bucket.list_blobs(prefix=blob_name)  
  
    table_id = "compact-marker-420904.rag_data.extracted_text"  
    rows_to_insert = []  
  
    for blob in blobs:  
        print(blob.name)  
        if blob.name.endswith(".pdf"):  
            print("Extracting text from {}".format(blob.name))  
            id = blob.name  # use blob name as id  
            text = extract_text(BytesIO(blob.download_as_bytes()))  
            filename = blob.name  
            character_length = len(text)  
            upload_time = datetime.datetime.now()  # use current time as upload time  
  
            row = (id, filename, upload_time, text, character_length)  
            rows_to_insert.append(row)  
  
    errors = client.insert_rows(client.get_table(table_id), rows_to_insert)  
    if errors == []:  
        print("New rows have been added.") 
        return True 
    else:  
        print("Encountered errors while inserting rows: {}".format(errors))  
        return False
  
download_and_store("test_21")  
