from pinecone import Pinecone, ServerlessSpec
from openai import OpenAI
from google.cloud import bigquery  

def get_matches(query="who is the godfather of harry potter?", namespace="test_29"):
    print("Querying Pinecone to get context")
    pc = Pinecone(api_key='')
    index_name = "bitcamp"
    index = pc.Index(index_name)

    # convert query to pinecone
    query = query

    def get_embedding(text, model="text-embedding-3-large"):
        openai_api_key = ""
        client = OpenAI(api_key=openai_api_key)
        text = text.replace("\n", " ")
        return client.embeddings.create(input = [text], model=model).data[0].embedding

    query_vector = get_embedding(query)

    results = index.query(
        namespace=namespace,
        vector=query_vector,
        top_k=3,
        include_values=True
    )

    # print(type(results))
    # print(results)
    ids = []
    for match in results['matches']:
        ids.append(match['id'])


    client = bigquery.Client(project="compact-marker-420904") 

    table_id = "compact-marker-420904.rag_data.chunks"  

    texts = []
    for id in ids: 
        bq_query = f"""  
            SELECT text  
            FROM `{table_id}`
            where id = '{id}'  
        """  
        res = client.query_and_wait(bq_query)
        # print(res)
        for row in res:
            texts.append(row['text'])

        print(texts)

    print("Created Openai Message")
    return f"{query}\n\nThis is the context for the query from which you need to answer:\n\n{texts}"

def call_openai(message, model="gpt-3.5-turbo"):
    print("Calling Openai")
    openai_api_key = ""
    client = OpenAI(api_key=openai_api_key)
    messages = [
        {"role": "system", "content": "You answer the question asked based on the context provided."},
        {"role": "user", "content": message},
    ]
    response = client.chat.completions.create(
        model=model,
        messages=messages,
        temperature=0
    )
    response_message = response.choices[0].message.content
    print("Returning Response from OPENAI")
    return response_message

# print(call_openai("minimum gpa", get_matches(query="gpa requirement")))