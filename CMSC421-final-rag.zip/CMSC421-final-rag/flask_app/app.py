from flask import Flask, request, jsonify  
import os  
from google.cloud import storage  
from extract_data import download_and_store  
from chunking.create_chunks import create_chunks  
from chunking.vectorize import vectorize  
from querying.pinecone_query import call_openai, get_matches  
  
app = Flask(__name__)  
  
def get_latest_folder_number(bucket_name="rag_documents_bitcamp"):  
    storage_client = storage.Client()  
    bucket = storage_client.bucket(bucket_name)        
    blobs = bucket.list_blobs()  
    folder_numbers = set()  
  
    for blob in blobs:  
        print(blob.name)
        if blob.name.endswith('/'): 
            folder_name = blob.name.rstrip('/')  
            if folder_name.startswith("test_"):  
                folder_numbers.add(int(folder_name.split("_")[1]))  
        elif "/" in blob.name:
            folder_name = blob.name.split("/")[0]
            if folder_name.startswith("test_"):  
                folder_numbers.add(int(folder_name.split("_")[1]))  
      
    if folder_numbers:  
        return max(folder_numbers) + 1  
    else:  
        return 1 
  
def create_next_folder(bucket_name="rag_documents_bitcamp"):  
    latest_folder_number = get_latest_folder_number(bucket_name)  
    next_folder_name = f"test_{latest_folder_number}"  
      
    storage_client = storage.Client()  
    bucket = storage_client.bucket(bucket_name)  
    blob = bucket.blob(f"{next_folder_name}/")   
    blob.upload_from_string('') 
      
    return next_folder_name  
  
def upload_files(files):    
    """Uploads files to a Google Cloud Storage bucket."""    
    
    bucket_name = "rag_documents_bitcamp"    
    
    storage_client = storage.Client()    
    
    bucket = storage_client.get_bucket(bucket_name)    
    
    next_folder_name = create_next_folder(bucket_name)    
    # print(next_folder_name)    
    # print(files)  
  
    for filename in files: 
        # print(next_folder_name)
        print("uploading", filename)
        blob = bucket.blob(f"{str(next_folder_name)}/{str(filename)}")    
        blob.upload_from_filename(filename)    


    # call next method which takes in the folder name as argument and extracts text from it
    return process_files(next_folder_name) 
  
def process_files(dir):
    # extracting text from files and adding to bigquery table "extracted_text"
    if download_and_store(dir):
        # chunking text
        if create_chunks(dir):
            # creating vectors and upserting
            if vectorize(dir):
                return "All Files Processed", 200
            else:
                return "Error in vectorization", 500
        else:
            return "Error in Chunking text", 501
    else:
        return "Error in Extracting text", 502

def query_rag(query, dir=None):  
    if dir is None:  
        dir = get_latest_folder_number("rag_documents_bitcamp") - 1  # Assuming you want the latest complete folder  
    return call_openai(get_matches(query, f"test_{dir}"), model="gpt-4-turbo") 


@app.route('/process', methods=['GET'])
def process():
    try:
        return process_files("test_" + str(get_latest_folder_number()-1))
    except Exception as e:
        return jsonify({"error": "process method:\n" + str(e)}), 500


@app.route('/new_folder', methods=['GET'])
def new_folder():
    try:
        return "test_" + str(get_latest_folder_number()), 200
    except Exception as e:
        return jsonify({"error": "new_folder method:\n" + str(e)}), 500

@app.route('/query', methods=['GET'])  
def query():  
    query = request.args.get('query', default='', type=str)  
    if query == '':  
        return jsonify({"error": "Empty query"}), 400  
      
    dir = get_latest_folder_number("rag_documents_bitcamp") - 1  
    # dir = 29
    response = query_rag(query, dir)  
      
    return jsonify({"response": response}), 200  
  
if __name__ == '__main__':  
    app.run(debug=True, host="0.0.0.0", port=int(os.environ.get("PORT", 8080)))  


 
