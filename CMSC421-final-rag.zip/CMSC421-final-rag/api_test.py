import requests  
  

url = 'https://bitcamp-rag-api-nraqo3vpqq-uk.a.run.app/query'  
data = {'query': 'summarize the syllabus', 'body': 'bar', 'userId': 1}  
  
response = requests.post(url, json=data)  
  
if response.status_code == 200:  
    print(response.json())  
else:  
    print(f"Failed to post data, status code: {response.status_code}")  
