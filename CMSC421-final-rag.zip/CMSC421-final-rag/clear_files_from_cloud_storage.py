from google.cloud import storage  
  
def clear_bucket(bucket_name):  
    """Clears all files and blobs from a Google Cloud Storage bucket."""  
  
    storage_client = storage.Client()  
  
    bucket = storage_client.get_bucket(bucket_name)  
  
    blobs = bucket.list_blobs()  
    for blob in blobs:  
        blob.delete()  
  
clear_bucket("rag_documents_bitcamp")  
