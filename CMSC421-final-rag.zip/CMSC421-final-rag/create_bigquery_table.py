from google.cloud import bigquery

client = bigquery.Client()

table_id = "compact-marker-420904.rag_data.vectors"

schema = [
    bigquery.SchemaField("id", "STRING"),
    bigquery.SchemaField("filename", "STRING"),
    bigquery.SchemaField("upload_time", "TIMESTAMP"),
    bigquery.SchemaField("text", "STRING"),
    bigquery.SchemaField("character_length", "INTEGER"),
    bigquery.SchemaField("vectors", "STRING"),
]

table = bigquery.Table(table_id, schema=schema)
table = client.create_table(table)

print(
    "Created table {}.{}.{}".format(table.project, table.dataset_id, table.table_id)
)